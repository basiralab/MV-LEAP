function I = learnNearestNeighbour(P,C,k)

[r c] = size(P);

[y, S, F, ydata,alpha] = SIMLR(P,C,k);

I = [];
for i=1:r
    s = S(i,:);
    j=1;
   while j<=k 
        n = max(s);
        indexNeighbors = find(s == max(s));
        if(length(indexNeighbors)==1)
            I(j,i) = indexNeighbors;
            s(indexNeighbors)=[];
            j=j+1;
        else
            for l=1:length(indexNeighbors)
                if(j<=k)
                    I(l,i) = indexNeighbors(l);
                    s(indexNeighbors(l))=[];       
                    j=j+1;
                end
            end
        end
   end
end

end