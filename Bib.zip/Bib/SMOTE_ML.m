function X_smote = mySMOTE(X, N, k, C)
% mySMOTE  Synthetic Minority Oversampling Technique. A technique to
% generate synthetic samples as given in: https://www.jair.org/media/953/live-953-2037-jair.pdf
%   Usage:
%   X_smote = mySMOTE(X, N, k) 
%   
%   Inputs:
%   X: Original dataset
%   N: Percentage of data-augmentation intended, Typically, N > 100, if N < 100, then N is set to 100.
%   k: number of nearest neighbors to consider while performing
%   augmentation
%   C: number of cluster for SIMLR 
%
%   Outputs:
%   X_smote: augmented dataset containing original data as well.
%   
%   See also datasample, randsample
%
% Edited by Olfa GRAA 2019

T = size(X, 1);

if N < 100
    N = 100;
end

N = floor(N / 100);
X_smote = X;

%SIMLR
    %Learn the nearest neighbour using SIMLR
    %P : input data (training matrix)
    %C : number of clusters {2,3,4}
    %k : number of neighbors {10,15,20}
    I = learnNearestNeighbour(X,C,k);

for i = 1:T
    y = X(i,:);

    %SMOTE
    idx = I(:,i);
    index_nearest = datasample(idx, N);
    if(index_nearest ~= 0)
        x_nearest = X(index_nearest,:);
    end
    x_syn = bsxfun(@plus, bsxfun(@times, bsxfun(@minus,x_nearest,y), rand(N,1)), y);
    X_smote = cat(1, X_smote, x_syn);
end

end